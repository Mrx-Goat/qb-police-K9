# POLICE K9 SCRIPT – HOW TO INSTALL

# Author: mrx-goat 🐐🔥

# 

# \---

# 

# SCRIPT INFO:

# 

# Lite PoliceK9 script for FiveM

# Supports ESX \& QBCore

# OX\_Target support included

# 

# Main Features:

# 

# \* Enter/Exit Vehicles

# \* Search / Attack Players

# \* Stay / Follow Commands

# \* Job \& Rank Lock

# \* Third-Eye Spawn System

# \* Search Vehicles (Trunk \& Glovebox)

# 

# \---

# 

# REQUIREMENTS:

# 

# \* QBCore or ESX

# \* qb-target or ox\_target

# \* oxmysql

# 

# \---

# 

# STEP 1: INSTALL SCRIPT

# 

# Put the script folder into:

# 

# resources/\[scripts]/policeK9

# 

# \---

# 

# STEP 2: ADD TO SERVER.CFG

# 

# Add this line:

# 

# ensure policeK9

# 

# \---

# 

# STEP 3: CONFIGURE SCRIPT

# 

# Go to:

# 

# policeK9/config.lua

# 

# Make sure:

# 

# Config.UseQBCore = true

# Config.ThirdEyeName = 'qb-target'

# 

# (Change to ox\_target if needed)

# 

# \---

# 

# STEP 4: SET K9 LOCATION

# 

# Find:

# 

# Config.K9Kennel = {

# vector3(453.94, -990.0, 30.69)

# }

# 

# Change coordinates if needed.

# 

# \---

# 

# STEP 5: ADD INVENTORY SUPPORT (IMPORTANT)

# 

# For QBCore users:

# 

# Go to:

# qb-inventory/server.lua

# OR

# ps-inventory/server.lua

# 

# Scroll to the bottom and paste:

# 

# \-- required for k9

# function getTrunkItems(plate)

# if Trunks\[plate] then

# return Trunks\[plate]

# else

# local result = MySQL.scalar.await('SELECT items FROM trunkitems WHERE plate = ?', {plate})

# if not result then return false end

# local data = {

# items = json.decode(result)

# }

# return data

# end

# end

# 

# function getGloveboxItems(plate)

# if Gloveboxes\[plate] then

# return Gloveboxes\[plate]

# else

# local result = MySQL.scalar.await('SELECT items FROM gloveboxitems WHERE plate = ?', {plate})

# if not result then return false end

# local data = {

# items = json.decode(result)

# }

# return data

# end

# end

# 

# exports("getGloveboxItems", getGloveboxItems)

# exports("getTrunkItems", getTrunkItems)

# \-- required for k9

# 

# \---

# 

# STEP 6: (OPTIONAL) ADD BLIP

# 

# Open client.lua and paste:

# 

# CreateThread(function()

# for k, v in pairs(Config.K9Kennel) do

# local blip = AddBlipForCoord(v.x, v.y, v.z)

# 

# ```

# &#x20;   SetBlipSprite(blip, 225)

# &#x20;   SetBlipDisplay(blip, 4)

# &#x20;   SetBlipScale(blip, 0.7)

# &#x20;   SetBlipColour(blip, 3)

# &#x20;   SetBlipAsShortRange(blip, true)

# 

# &#x20;   BeginTextCommandSetBlipName("STRING")

# &#x20;   AddTextComponentString("K9 Unit")

# &#x20;   EndTextCommandSetBlipName(blip)

# end

# ```

# 

# end)

# 

# \---

# 

# STEP 7: HOW TO USE

# 

# Go to K9 location

# Use third-eye (qb-target / ox\_target)

# Spawn your K9

# 

# Controls:

# E = Search

# G = Attack

# F = Follow

# B = Stay

# 

# \---

# 

# STEP 8: RESTART SERVER

# 

# restart policeK9

# 

# mytiktok:www.tiktok.com/@mrx\_goat\_ht  

# &#x20;         

# &#x20;follow me please



# 

# DONE ✔️

# 

# \## Enjoy your K9 system 🐕🔥



